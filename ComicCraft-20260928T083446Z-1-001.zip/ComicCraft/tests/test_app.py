import os
os.environ["DEMO_MODE"]="true"
from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def test_homepage():
    r=client.get("/"); assert r.status_code==200; assert "ComicCraft" in r.text
def test_health():
    r=client.get("/health"); assert r.status_code==200; assert r.json()["status"]=="ok"
def test_json_generation_demo():
    payload={"story_prompt":"A brave fox explores an enchanted forest.","character_name":"Finn","setting":"forest","tone":"dramatic","art_style":"comic book"}
    r=client.post("/generate-comic/json",json=payload); assert r.status_code==200; d=r.json(); assert d["success"] is True; assert len(d["panels"])==5; assert d["pdf_path"].startswith("/static/exports/")
