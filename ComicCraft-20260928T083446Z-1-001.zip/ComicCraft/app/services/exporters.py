from datetime import datetime
from fpdf import FPDF
from PIL import Image
from app.config import Settings

def _safe_text(value):
    return str(value).encode("latin-1", "replace").decode("latin-1")

def _text(pdf, value, style="", size=11):
    pdf.set_x(15)
    pdf.set_font("Helvetica", style, size)
    pdf.multi_cell(180, 7, _safe_text(value), align="L")

def save_pdf(layout, settings: Settings):
    filename=f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
    output=settings.export_path/filename
    pdf=FPDF(); pdf.set_auto_page_break(auto=True, margin=15)
    for panel in layout:
        pdf.add_page(); _text(pdf, f"Panel {panel['panel_number']}: {panel['title']}", "B", 18)
        image_path=settings.panel_path/panel["image_path"].rsplit("/",1)[-1]
        if image_path.exists():
            with Image.open(image_path) as img: w,h=img.size
            scale=min(180/w,105/h)
            pdf.image(str(image_path), x=15, y=pdf.get_y()+4, w=w*scale, h=h*scale)
            pdf.set_y(pdf.get_y()+h*scale+10)
        _text(pdf, panel["scene_description"], "I", 11)
        _text(pdf, "Caption: "+panel["caption"], "B", 11)
        _text(pdf, "Narration: "+panel["narration"], "", 11)
        _text(pdf, "Dialogue: "+panel["dialogue"], "", 11)
    pdf.output(str(output))
    return f"/static/exports/{filename}"
