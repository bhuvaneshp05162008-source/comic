def build_comic_layout(outline, story, image_paths):
    story_by_panel = {x["panel_number"]: x for x in story}; layout = []
    for panel in outline:
        n = panel["panel_number"]; s = story_by_panel.get(n, {})
        layout.append({"panel_number": n, "title": panel["title"], "scene_description": panel["scene_description"], "image_prompt": panel["image_prompt"], "image_path": image_paths[n-1], "caption": s.get("caption", ""), "narration": s.get("narration", ""), "dialogue": s.get("dialogue", "")})
    return layout
