from pathlib import Path
import hashlib
from PIL import Image, ImageDraw, ImageFont
from app.config import Settings

def _safe_name(prompt, panel_number): return f"panel_{panel_number}_{hashlib.sha256(prompt.encode()).hexdigest()[:12]}.png"

def _placeholder(prompt, output: Path, panel_number):
    image = Image.new("RGB", (1024, 768), "white"); draw = ImageDraw.Draw(image)
    try: font = ImageFont.truetype("DejaVuSans.ttf", 36); small = ImageFont.truetype("DejaVuSans.ttf", 22)
    except OSError: font = small = ImageFont.load_default()
    draw.rectangle((20,20,1004,748), outline="black", width=6); draw.text((60,70), f"COMICCRAFT — PANEL {panel_number}", fill="black", font=font); draw.text((60,170), prompt[:500], fill="black", font=small, spacing=8); draw.text((60,650), "Demo image — enable Hugging Face inference for AI artwork.", fill="black", font=small); image.save(output, "PNG")

def generate_image(prompt: str, panel_number: int, settings: Settings) -> str:
    output = settings.panel_path / _safe_name(prompt, panel_number)
    if settings.demo_mode: _placeholder(prompt, output, panel_number); return f"/static/panels/{output.name}"
    if not settings.hf_token: raise RuntimeError("HF_TOKEN is not configured. Set it in .env or enable DEMO_MODE.")
    from huggingface_hub import InferenceClient
    client = InferenceClient(provider=settings.hf_provider, api_key=settings.hf_token)
    image = client.text_to_image(prompt=prompt, model=settings.hf_image_model); image.save(output, "PNG")
    return f"/static/panels/{output.name}"
