import json, re
from app.config import Settings
from app.models import PromptRequest

def _extract_json(text: str):
    text = re.sub(r"^```(?:json)?\s*", "", text.strip(), flags=re.I); text = re.sub(r"\s*```$", "", text); return json.loads(text)

def _demo_story(outline, request):
    c, s = request.character_name, request.setting
    caps = ["A quiet beginning...", "Something is not quite right...", "The moment of truth!", "Courage changes everything.", "The adventure continues."]
    nar = [f"{c} stepped into the {s}, determined to discover what was waiting beyond the familiar path.", f"Behind an old landmark, {c} found a clue that seemed to connect directly to the strange story.", f"When the challenge appeared, {c} took a breath and chose to move forward instead of turning back.", f"With quick thinking and courage, {c} transformed a difficult moment into a chance to succeed.", f"As the {s} became peaceful again, {c} smiled, knowing this was only the beginning of a bigger adventure."]
    dia = [f'{c}: "I have a feeling this is just the start."', f'{c}: "What could this clue possibly mean?"', f'{c}: "I can do this!"', f'{c}: "There has to be another way."', f'{c}: "Tomorrow, I will see where the next path leads."']
    return [{"panel_number": i+1, "caption": caps[i], "narration": nar[i], "dialogue": dia[i]} for i in range(5)]

def generate_story(outline, request: PromptRequest, settings: Settings):
    if settings.demo_mode: return _demo_story(outline, request)
    if not settings.gemini_api_key: raise RuntimeError("GEMINI_API_KEY is not configured. Set it in .env or enable DEMO_MODE.")
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f'''Expand this five-panel comic outline into concise comic narration and dialogue.
Character: {request.character_name}; Setting: {request.setting}; Tone: {request.tone}; Art style: {request.art_style}
Outline: {json.dumps(outline, ensure_ascii=False)}
Return ONLY JSON as an array of exactly five objects. Each object must contain panel_number, caption, narration, dialogue. Keep the panel order.'''
    response = client.models.generate_content(model=settings.gemini_pro_model, contents=prompt, config=types.GenerateContentConfig(temperature=1.0, max_output_tokens=3500, response_mime_type="application/json"))
    data = _extract_json(response.text or "")
    if not isinstance(data, list) or len(data) != 5: raise ValueError("Gemini did not return exactly five story panels.")
    return [{"panel_number": i, "caption": str(p.get("caption", "")), "narration": str(p.get("narration", "")), "dialogue": str(p.get("dialogue", ""))} for i, p in enumerate(data, 1)]
