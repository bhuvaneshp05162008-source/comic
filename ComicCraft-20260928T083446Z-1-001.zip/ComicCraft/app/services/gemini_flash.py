import json, re
from typing import Any
from app.config import Settings
from app.models import PromptRequest

def _extract_json(text: str) -> Any:
    text = re.sub(r"^```(?:json)?\s*", "", text.strip(), flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    try: return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("["), text.rfind("]")
        if start >= 0 and end > start: return json.loads(text[start:end+1])
        raise

def _demo_outline(request: PromptRequest) -> list[dict]:
    c, s = request.character_name, request.setting
    titles = ["The Beginning", "A Strange Discovery", "The Challenge", "The Turning Point", "A New Beginning"]
    descriptions = [f"{c} arrives at the {s}, sensing that an unusual adventure is about to begin.", f"{c} discovers a mysterious clue hidden inside the {s}.", f"A sudden challenge forces {c} to make a brave choice.", f"{c} uses courage and creativity to solve the central problem.", f"The adventure ends with {c} changed by what happened in the {s}."]
    return [{"panel_number": i+1, "title": titles[i], "scene_description": descriptions[i], "image_prompt": f"{c}, in a {s}, {descriptions[i]} {request.art_style} comic illustration, cinematic composition, expressive character, detailed background"} for i in range(5)]

def generate_outline(request: PromptRequest, settings: Settings) -> list[dict]:
    if settings.demo_mode: return _demo_outline(request)
    if not settings.gemini_api_key: raise RuntimeError("GEMINI_API_KEY is not configured. Set it in .env or enable DEMO_MODE.")
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f'''Create a coherent five-panel comic outline.
Story prompt: {request.story_prompt}
Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}
Return ONLY valid JSON as an array of exactly five objects. Each object must contain panel_number, title, scene_description, image_prompt. Do not include markdown fences.'''
    response = client.models.generate_content(model=settings.gemini_flash_model, contents=prompt, config=types.GenerateContentConfig(temperature=0.9, max_output_tokens=2500, response_mime_type="application/json"))
    data = _extract_json(response.text or "")
    if not isinstance(data, list) or len(data) != 5: raise ValueError("Gemini did not return exactly five panels.")
    return [{"panel_number": i, "title": str(p.get("title", f"Panel {i}")), "scene_description": str(p.get("scene_description", "")), "image_prompt": str(p.get("image_prompt", ""))} for i, p in enumerate(data, 1)]
