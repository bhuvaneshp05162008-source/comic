from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from app.config import get_settings
from app.models import ImageTestRequest, PromptRequest
from app.services.exporters import save_pdf
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout

router=APIRouter(); templates=Jinja2Templates(directory="templates"); settings=get_settings()

def run_generation(payload):
    outline=generate_outline(payload,settings); story=generate_story(outline,payload,settings); images=[generate_image(p["image_prompt"],p["panel_number"],settings) for p in outline]; layout=build_comic_layout(outline,story,images); return outline,story,layout,save_pdf(layout,settings)

@router.get("/",response_class=HTMLResponse)
async def home(request:Request): return templates.TemplateResponse(request=request,name="index.html",context={"settings":settings})

@router.post("/generate",response_class=HTMLResponse)
async def generate(request:Request,story_prompt:str=Form(...),character_name:str=Form(...),setting:str=Form(...),tone:str=Form(...),art_style:str=Form(...)):
    form={"story_prompt":story_prompt,"character_name":character_name,"setting":setting,"tone":tone,"art_style":art_style}
    try:
        _,_,layout,pdf_path=run_generation(PromptRequest(**form)); return templates.TemplateResponse(request=request,name="comic_preview.html",context={"layout":layout,"pdf_path":pdf_path,"settings":settings})
    except Exception as exc:
        return templates.TemplateResponse(request=request,name="index.html",context={"settings":settings,"error":str(exc),"form":form},status_code=500)

@router.post("/generate-comic/json")
async def generate_json(payload:PromptRequest):
    try:
        _,_,layout,pdf_path=run_generation(payload); return JSONResponse({"success":True,"panels":layout,"pdf_path":pdf_path})
    except Exception as exc: raise HTTPException(status_code=500,detail=str(exc))

@router.post("/test-image")
async def test_image(payload:ImageTestRequest):
    try: return {"success":True,"image_path":generate_image(payload.prompt,0,settings)}
    except Exception as exc: raise HTTPException(status_code=500,detail=str(exc))

@router.get("/export-success",response_class=HTMLResponse)
async def export_success(request:Request,pdf_path:str=""): return templates.TemplateResponse(request=request,name="export_success.html",context={"pdf_path":pdf_path,"settings":settings})

@router.get("/health")
async def health(): return {"status":"ok","app":settings.app_name,"demo_mode":settings.demo_mode,"gemini_configured":bool(settings.gemini_api_key),"huggingface_configured":bool(settings.hf_token)}
