from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    host: str = "127.0.0.1"
    port: int = 8000
    demo_mode: bool = True
    gemini_api_key: str = ""
    gemini_flash_model: str = "gemini-2.5-flash"
    gemini_pro_model: str = "gemini-2.5-pro"
    hf_token: str = ""
    hf_provider: str = "hf-inference"
    hf_image_model: str = "stabilityai/stable-diffusion-3.5-large-turbo"
    panel_dir: str = "static/panels"
    export_dir: str = "static/exports"
    max_panels: int = 5
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", case_sensitive=False, extra="ignore")

    @property
    def panel_path(self) -> Path:
        p = BASE_DIR / self.panel_dir; p.mkdir(parents=True, exist_ok=True); return p
    @property
    def export_path(self) -> Path:
        p = BASE_DIR / self.export_dir; p.mkdir(parents=True, exist_ok=True); return p

@lru_cache
def get_settings() -> Settings:
    return Settings()
