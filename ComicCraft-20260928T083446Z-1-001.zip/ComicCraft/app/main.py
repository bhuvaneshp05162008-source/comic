from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.config import get_settings
from app.routes import router
settings=get_settings(); Path(settings.panel_path).mkdir(parents=True,exist_ok=True); Path(settings.export_path).mkdir(parents=True,exist_ok=True)
app=FastAPI(title=settings.app_name,description="AI Comic Story Creator using Gemini and Hugging Face image generation.",version="1.0.0")
app.mount("/static",StaticFiles(directory="static"),name="static"); app.include_router(router)
